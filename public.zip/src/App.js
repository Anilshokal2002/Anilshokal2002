import './App.css';
// import { BrowserRouter as Router,Routes,Route} from "react-router-dom"
import Header from './Component/Header/Header';
import Popup from './Component/Header/Popup';

function App() {


  return (
  <>
    
    {/* <Router> */}
      <Header/>
      {/* <Routes> */}
      {/* <Route/> */}
      {/* </Routes> */}
    {/* </Router> */}
  <Popup/>
    </>
  );
}

export default App;
